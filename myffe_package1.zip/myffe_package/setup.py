from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="myffe",        # this is package name
    version="1.0.3",     # this is the Version Number
    author="wbk",  # this is author's name 
    author_email="1757175380@qq.com",   #this is author's email    
    description="Feature Engineering Framework - A comprehensive tool for data preprocessing and feature engineering",
    long_description=long_description,   #Import the library's README.md file as the long description
    long_description_content_type="text/markdown", #Specify the content type of the long description as Markdown
    url="https://github.com/nan-luoyan-nan/myffe", #this is the source code repository URL 
    packages=find_packages(),     #from __init__ 
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],                                #These are the classifiers that describe the package's purpose and environment
    python_requires=">=3.7",
    install_requires=[      #this is the list of dependencies required to install the package
        "pandas>=1.3.0",
        "numpy>=1.20.0",
        "scikit-learn>=0.24.0",
        "scipy>=1.6.0",
        "imbalanced-learn>=0.8.0",
    ],
    keywords=[             #this is the list of keywords that describe the package's purpose and environment
        "feature engineering",
        "machine learning",
        "data preprocessing",
        "data cleaning",
        "data science",
        "python",
    ],
    include_package_data=True,  #include non-Python files specified in MANIFEST.in
    # MANIFEST.in is package list file
    package_data={
        "myffe": ["docs/*.json", "docs/*.txt"],  #extra files to include in the package
    },
)
