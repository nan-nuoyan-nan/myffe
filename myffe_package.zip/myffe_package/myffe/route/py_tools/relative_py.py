﻿import pandas as pd
import numpy as np
from scipy import stats

def is_numeric_columns(col):
    """判断列是否为数值类型
    
    Args:
        col: list，列数据
    
    Returns:
        bool: 是否为数值类型
    """
    for s in col:
        try:
            float(s)
        except ValueError:
            return False
    return True

def analyze_relative_distribution(data):
    """分析数据的相关性分布，推荐适合的特征工程方法
    
    Args:
        data: pandas DataFrame，输入数据
    
    Returns:
        dict: 包含特征工程参数的字典
    """
    # 初始化处理路线
    relative_route = {}
    
    # 找出数值列
    numeric_columns = []
    for col in data.columns:
        col_data = data[col].astype(str).tolist()
        if is_numeric_columns(col_data):
            numeric_columns.append(col)
    
    # 构建参数配置
    relative_params = {
        'clean_type': 'normal',
        'choice3_normal': ['skip'],
        'choice3_advance': ['skip'],
        'linear_cols': ','.join(numeric_columns),
        'linear_threshold': 0.75,
        'feature_cols': ','.join(numeric_columns),
        'feature_threshold': 0.75,
        'relation_func': 'func1',
        'pca_cols': ','.join(numeric_columns),
        'n_components': 10,
        'kernel_selection': 'pca',
        'n_features': 10
    }
    
    if len(numeric_columns) >= 2:
        # 计算相关性矩阵
        try:
            corr_matrix = data[numeric_columns].corr()
            
            # 分析相关性特征
            max_corr = corr_matrix.abs().max().max()
            mean_corr = corr_matrix.abs().mean().mean()
            
            # 分析数据特征
            data_size = len(data)
            num_features = len(numeric_columns)
            
            # 确定模式和推荐方法
            if data_size > 1000 or num_features > 10:
                # 大数据集或多特征使用高级模式
                relative_params['clean_type'] = 'advance'
                choice3 = []
                
                # 高相关性处理
                if max_corr > 0.7:
                    choice3.append('linear_plus')
                
                # 非线性特征构建
                if mean_corr > 0.3:
                    choice3.append('feature_plus')
                
                # 降维处理
                if num_features > 15:
                    choice3.append('pca_lda_kernel')
                
                # 特征重要性评估
                if num_features > 5:
                    choice3.append('feature_importance')
                
                if not choice3:
                    choice3.append('skip')
                
                relative_params['choice3_advance'] = choice3
            else:
                # 小数据集使用普通模式
                relative_params['clean_type'] = 'normal'
                choice3 = []
                
                # 高相关性处理
                if max_corr > 0.7:
                    choice3.append('linear_plus')
                
                # 非线性特征构建
                if mean_corr > 0.3:
                    choice3.append('feature_plus')
                
                # 特征重要性评估
                if num_features > 5:
                    choice3.append('feature_importance')
                
                if not choice3:
                    choice3.append('skip')
                
                relative_params['choice3_normal'] = choice3
        except Exception:
            pass
    
    relative_route['relative_preprocessing'] = relative_params
    
    return relative_route

def relative_py(data, auto_test=False):
    """Python实现的相关性分析和特征工程
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含特征工程参数的字典
    """
    return analyze_relative_distribution(data)
