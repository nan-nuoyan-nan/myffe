﻿import pandas as pd
import numpy as np

# 导入所需模块
import sys
import os

# 添加MFM目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
# py_tools -> route -> FFEv3_2 -> FFE -> MFM -> 根目录
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))))
if root_dir not in sys.path:
    sys.path.append(root_dir)

from myffe.tools.交互式 import interactive
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.visualize_route import visualize_route

def is_time_column(col):
    """判断列是否为时间类型
    
    Args:
        col: list，列数据
    
    Returns:
        bool: 是否为时间类型
    """
    # 只检查第一行数据
    if not col:
        return False
    
    # 取第一行数据进行测试
    first_value = col[0]
    
    # 尝试将第一行转换为时间格式
    try:
        time_data = pd.to_datetime(first_value, errors='coerce')
        # 检查是否为有效的时间值
        return pd.notna(time_data)
    except:
        return False

def analyze_time_distribution(data, auto_test=False):
    """分析数据的时间分布，推荐适合的时间处理方法
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含时间处理参数的字典
    """
    # 初始化处理路线
    time_route = {}
    
    # 展示数据前5行
    ColorPrinter.print_info("=" * 60)
    ColorPrinter.print_info("数据前5行：")
    ColorPrinter.print_info("=" * 60)
    ColorPrinter.print_any(data.head(), color='white')
    ColorPrinter.print_any("", color='white')
    
    # 询问是否使用智能推荐
    inter_time = False
    if auto_test:
        print("\033[31m下面进行测试使用智能推荐\033[0m")
        inter_time = True
    else:
        inter_time_tem = interactive(['ok', 'no'], title="是否使用智能推荐？", description="选择'ok'将自动检测时间列并设置处理方法，选择'no'需要手动选择", min_select=0, max_select=1).run()
        if inter_time_tem is None or (isinstance(inter_time_tem, list) and len(inter_time_tem) == 0):
            inter_time = 'skip'
        elif isinstance(inter_time_tem, list) and len(inter_time_tem) > 0:
            inter_time_tem = inter_time_tem[0]
            if inter_time_tem == 'ok':
                inter_time = True
            else:
                inter_time = False
        else:
            inter_time = False
    
    # 找出时间列
    time_columns = []
    # 常见的时间列名称
    time_column_names = [
        'date', 'time', 'timestamp', 'datetime', 'Date', 'Time', 'Timestamp', 'Datetime',
        'created_at', 'updated_at', 'start_time', 'end_time', 'event_time', 'record_time',
        'order_time', 'purchase_time', 'transaction_time', 'register_time', 'login_time',
        'created', 'updated', 'start', 'end', 'event', 'record',
        'order', 'purchase', 'transaction', 'register', 'login'
    ]
    
    # 首先检查常见的时间列名称
    for col in data.columns:
        if col.lower() in [name.lower() for name in time_column_names]:
            time_columns.append(col)
    
    # 检查已经是datetime类型的列
    for col in data.columns:
        if pd.api.types.is_datetime64_any_dtype(data[col]):
            if col not in time_columns:
                time_columns.append(col)
    
    # 尝试检测具有时间格式的列
    if not time_columns:
        for col in data.columns:
            # 跳过数字列
            if pd.api.types.is_numeric_dtype(data[col]):
                continue
                
            # 处理字符串类型的列
            if data[col].dtype == 'object' or data[col].dtype == 'string' or str(data[col].dtype) == 'str':
                try:
                    # 尝试将列转换为数字，如果能转换则排除
                    numeric_data = pd.to_numeric(data[col], errors='coerce')
                    if numeric_data.notnull().mean() > 0.9:  # 90%以上能转换为数字，则排除
                        continue
                        
                    # 只取第一行数据进行测试
                    first_value = data[col].iloc[0]
                    if pd.isna(first_value):
                        continue
                        
                    # 检查第一行是否为时间格式
                    time_data = pd.to_datetime(first_value, errors='coerce')
                    if pd.notna(time_data):
                        # 检查整体转换率
                        full_time_data = pd.to_datetime(data[col], errors='coerce')
                        conversion_rate = full_time_data.notnull().mean()
                        if conversion_rate > 0.6:  # 至少60%的数据可以转换为时间
                            time_columns.append(col)
                except Exception as e:
                    ColorPrinter.print_warning(f"检测列 {col} 时出错: {e}")
    
    # 构建参数配置
    time_params = {
        'time_col': None
    }
    
    if inter_time == 'skip':
        ColorPrinter.print_info("跳过时间列处理")
        return 'skip'
    
    if inter_time:
        # 智能推荐模式
        if time_columns:
            time_params['time_col'] = time_columns[0]
            ColorPrinter.print_success(f"智能推荐时间列：{time_columns[0]}")
        else:
            ColorPrinter.print_info("智能推荐：未检测到时间列")
    else:
        # 手动选择模式
        all_cols = list(data.columns)
        ColorPrinter.print_info("请选择时间列（按'm'键多选，按回车键确认）")
        selected_cols = interactive(all_cols, title="请按上下箭头选择，回车确认时间列,点击'm'键进行多选择", description="选择作为时间索引的列", min_select=0, max_select=1).run()
        
        # 确保返回值是列表
        if selected_cols is None:
            time_cols = []
        elif isinstance(selected_cols, str):
            time_cols = [selected_cols]
        else:
            time_cols = selected_cols
        
        if time_cols:
            time_params['time_col'] = time_cols[0]
    
    time_route['time_preprocessing'] = time_params
    
    visualize_route(time_route)
    return time_route

def time_py(data, auto_test=False):
    """Python实现的时间处理分析
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含时间处理参数的字典
    """
    
    return analyze_time_distribution(data, auto_test=auto_test)

if __name__ == "__main__":
    # 测试代码
    import pandas as pd
    import numpy as np
    
    # 创建测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=20),
        'numeric_col1': np.random.normal(100, 10, 20),
        'numeric_col2': np.random.normal(50, 5, 20),
        'categorical_col': np.random.choice(['A', 'B', 'C'], 20)
    })
    
    ColorPrinter.print_info("测试数据:")
    ColorPrinter.print_any(data.head(), color='white')
    ColorPrinter.print_any("\n数据类型:", color='blue')
    ColorPrinter.print_any(data.dtypes, color='white')
    
    # 测试时间处理
    ColorPrinter.print_info("\n测试时间处理:")
    result = time_py(data)
    ColorPrinter.print_success("处理结果:")
    ColorPrinter.print_any(result, color='white')
