﻿import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..')))

import pandas as pd
import numpy as np
from myffe.tools.交互式 import interactive
from myffe.tools.visualize_route import visualize_route
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.param_utils import ensure_list, convert_to_list

def analyze_sample_distribution(data, label_columns=None):
    """分析数据的类别分布，推荐适合的采样处理方法"""
    # 初始化采样处理路线
    sample_route = {}
    
    # 找出可能的标签列（假设是最后一列或名为'label'的列）
    if label_columns is None:
        label_columns = []
        # 检查是否有'label'列
        if 'label' in data.columns:
            label_columns.append('label')
        # 检查最后一列是否可能是标签列
        elif len(data.columns) > 0:
            last_col = data.columns[-1]
            label_columns.append(last_col)
    
    # 对每个可能的标签列进行分析
    for label_col in label_columns:
        # 检查该列是否适合作为标签列
        label_data = data[label_col]
        
        # 计算类别分布
        class_counts = label_data.value_counts()   # 计算每个类别的样本数量
        num_classes = len(class_counts)     # 类别数量
        total_samples = len(label_data)     # 总样本数量
        
        # 计算类别不平衡度
        if num_classes > 1:
            max_count = class_counts.max()
            min_count = class_counts.min()
            imbalance_ratio = max_count / min_count if min_count > 0 else float('inf')
        else:
            imbalance_ratio = 1.0
        
        # 分析数据特征，推荐适合的采样方法和模式
        recommended_configs = []
        
        # 基于类别数量和不平衡度推荐方法
        if num_classes == 1:
            # 只有一个类别，不需要采样
            recommended_configs.append({
                'mode': 'normal',
                'choice1_normal': ['skip'],
                'description': '跳过采样（只有一个类别）'
            })
        elif num_classes == 2:
            # 二分类问题
            if imbalance_ratio > 10:
                # 严重不平衡，推荐高级模式的SMOTE或ADASYN
                recommended_configs.extend([
                    {
                        'mode': 'advance',
                        'choice1_advance': ['MY_high_sample'],
                        'high_sample_selection': 'SMOTE',
                        'smote_k_neighbors': 5,
                        'description': 'SMOTE高级采样（严重不平衡二分类）'
                    },
                    {
                        'mode': 'advance',
                        'choice1_advance': ['MY_high_sample'],
                        'high_sample_selection': 'ADASYN',
                        'adasyn_n_neighbors': 5,
                        'description': 'ADASYN高级采样（严重不平衡二分类）'
                    }
                ])
            elif imbalance_ratio > 2:
                # 中度不平衡，推荐高级模式的RandomOverSampler或BorderlineSMOTE
                recommended_configs.extend([
                    {
                        'mode': 'advance',
                        'choice1_advance': ['MY_high_sample'],
                        'high_sample_selection': 'RandomOverSampler',
                        'description': 'RandomOverSampler高级采样（中度不平衡二分类）'
                    },
                    {
                        'mode': 'advance',
                        'choice1_advance': ['MY_high_sample'],
                        'high_sample_selection': 'BorderlineSMOTE',
                        'borderline_smote_k_neighbors': 5,
                        'description': 'BorderlineSMOTE高级采样（中度不平衡二分类）'
                    }
                ])
            else:
                # 平衡数据，推荐普通模式的skip
                recommended_configs.append({
                    'mode': 'normal',
                    'choice1_normal': ['skip'],
                    'description': '跳过采样（平衡二分类）'
                })
        else:
            # 多分类问题
            if imbalance_ratio > 5:
                # 严重不平衡，推荐高级模式的SMOTE或普通模式的过采样
                recommended_configs.extend([     #extend方法将可迭代对象里面的东西添加到指定的列表的后面
                    {
                        'mode': 'advance',
                        'choice1_advance': ['MY_high_sample'],
                        'high_sample_selection': 'SMOTE',
                        'smote_k_neighbors': 5,
                        'description': 'SMOTE高级采样（严重不平衡多分类）'
                    },
                    {
                        'mode': 'normal',
                        'choice1_normal': ['multi_class_balance'],
                        'balance_method': 'oversample',
                        'random_state': 42,
                        'description': '普通模式过采样（严重不平衡多分类）'
                    }
                ])
            elif imbalance_ratio > 2:
                # 中度不平衡，推荐普通模式的过采样
                recommended_configs.append({
                    'mode': 'normal',
                    'choice1_normal': ['multi_class_balance'],
                    'balance_method': 'oversample',
                    'random_state': 42,
                    'description': '普通模式过采样（中度不平衡多分类）'
                })
            else:
                # 平衡数据，推荐普通模式的skip
                recommended_configs.append({
                    'mode': 'normal',
                    'choice1_normal': ['skip'],
                    'description': '跳过采样（平衡多分类）'
                })
        
        # 基于数据量大小调整推荐
        if total_samples < 1000:
            # 小数据集，优先推荐计算量较小的方法
            lightweight_configs = [config for config in recommended_configs if 
                                 (config['mode'] == 'normal' and 'multi_class_balance' in config.get('choice1_normal', [])) or
                                 (config['mode'] == 'advance' and config.get('high_sample_selection') in ['RandomOverSampler', 'RandomUnderSampler'])]
            if lightweight_configs:
                recommended_configs = lightweight_configs
        elif total_samples > 100000:
            # 大数据集，优先推荐高效的方法
            efficient_configs = [config for config in recommended_configs if 
                               (config['mode'] == 'normal') or
                               (config['mode'] == 'advance' and config.get('high_sample_selection') in ['RandomOverSampler', 'RandomUnderSampler'])]
            if efficient_configs:
                recommended_configs = efficient_configs
        
        # 为该标签列创建采样路线
        if recommended_configs:
            # 提取最佳配置
            best_config = recommended_configs[0]
            
            # 构建完整的参数配置，与参数配置文档和 sample_preprocessing.py 完全兼容
            sample_params = {}
            if best_config['mode'] == 'normal':
                # choice1_normal 可以是字符串或列表
                sample_params['choice1_normal'] = best_config.get('choice1_normal', 'skip')
                if 'multi_class_balance' in (sample_params['choice1_normal'] if isinstance(sample_params['choice1_normal'], list) else [sample_params['choice1_normal']]):
                    sample_params['balance_method'] = best_config.get('balance_method', 'oversample')
                    sample_params['random_state'] = best_config.get('random_state', 42)
            else:
                # choice1_advance 可以是字符串或列表
                sample_params['choice1_advance'] = best_config.get('choice1_advance', 'MY_high_sample')
                if 'MY_high_sample' in (sample_params['choice1_advance'] if isinstance(sample_params['choice1_advance'], list) else [sample_params['choice1_advance']]):
                    sample_params['high_sample_selection'] = best_config.get('high_sample_selection', 'RandomOverSampler')
                    # 添加相应的参数，与 sample_preprocessing.py 中的默认值一致
                    if sample_params['high_sample_selection'] == 'SMOTE':
                        sample_params['smote_k_neighbors'] = best_config.get('smote_k_neighbors', 5)
                    elif sample_params['high_sample_selection'] == 'ADASYN':
                        sample_params['adasyn_n_neighbors'] = best_config.get('adasyn_n_neighbors', 5)
                    elif sample_params['high_sample_selection'] == 'BorderlineSMOTE':
                        sample_params['borderline_smote_k_neighbors'] = best_config.get('borderline_smote_k_neighbors', 5)
                    elif sample_params['high_sample_selection'] == 'SVMSMOTE':
                        sample_params['svm_smote_k_neighbors'] = best_config.get('svm_smote_k_neighbors', 5)
                    elif sample_params['high_sample_selection'] == 'EditedNearestNeighbours':
                        sample_params['enn_n_neighbors'] = best_config.get('enn_n_neighbors', 5)
            
            sample_route[label_col] = {
                'num_classes': num_classes,
                'total_samples': total_samples,
                'imbalance_ratio': round(imbalance_ratio, 2),
                'recommended_configs': recommended_configs,
                'best_config': best_config,
                'best_params': sample_params,
                'best_method': best_config['description']
            }
    
    return sample_route

def get_label_columns(data):
    """获取数据中的标签列"""
    label_columns = []
    # 检查是否有'label'列
    if 'label' in data.columns:
        label_columns.append('label')
    # 检查最后一列是否可能是标签列
    elif len(data.columns) > 0:
        last_col = data.columns[-1]
        label_columns.append(last_col)
    return label_columns

def sample_py(data, label_columns=None, auto_test=False):
    """Python实现的采样处理分析"""
    # 首先获取标签列
    if label_columns is None:
        label_columns = get_label_columns(data)
    else:
        label_columns = ensure_list(label_columns)
    
    if not label_columns:
        ColorPrinter.print_info("没有发现标签列，跳过采样处理")
        return 'skip'
    
    # 分析样本分布
    sample_route = analyze_sample_distribution(data, label_columns)
    
    if not sample_route:
        ColorPrinter.print_info("无法分析样本分布，跳过采样处理")
        return 'skip'
    
    # 获取第一个标签列的分析结果
    label_col = list(sample_route.keys())[0]
    analysis = sample_route[label_col]
    
    # 显示分析信息
    ColorPrinter.print_info(f"标签列: {label_col}")
    ColorPrinter.print_info(f"类别数量: {analysis['num_classes']}")
    ColorPrinter.print_info(f"总样本数量: {analysis['total_samples']}")
    ColorPrinter.print_info(f"类别不平衡度: {analysis['imbalance_ratio']}")
    ColorPrinter.print_info(f"推荐方法: {analysis['best_method']}")
    
    # 智能推荐菜单
    if auto_test:
        print("\033[31m下面进行测试使用智能推荐\033[0m")
        choice = "使用推荐方案"
    else:
        menu_options = [
            "使用推荐方案",
            "自定义处理方案",
            "跳过处理"
        ]
        menu = interactive(menu_options, title="采样处理", description="请选择处理方式:")
        
        selected = menu.run()
        selected_list = ensure_list(selected)
        choice = selected_list[0] if selected_list else "跳过处理"
    
    if choice == "跳过处理":
        ColorPrinter.print_info("跳过采样处理")
        return 'skip'
    
    elif choice == "使用推荐方案":
        ColorPrinter.print_success("使用推荐方案")
        # 使用推荐参数
        sample_params = analysis['best_params']
        
        # 构建结果
        result = {'sample_preprocessing': sample_params}
        
        # 可视化处理路线
        visualize_route(result)
        
        return result
    elif choice == "自定义处理方案":
        # 自定义处理方案
        ColorPrinter.print_info("自定义处理方案")
        
        # 1. 选择模式
        mode_options = ["普通模式", "高级模式"]
        mode_menu = interactive(mode_options, title="选择模式", description="请选择采样模式:")
        mode_selected = mode_menu.run()
        mode_selected_list = ensure_list(mode_selected)
        mode = mode_selected_list[0] if mode_selected_list else "普通模式"
        
        # 初始化参数
        sample_params = {
            'choice1_normal': ['skip'],
            'choice1_advance': ['skip'],
            'balance_method': 'oversample',
            'random_state': 42,
            'high_sample_selection': 'RandomOverSampler',
            'smote_k_neighbors': 5,
            'adasyn_n_neighbors': 5,
            'borderline_smote_k_neighbors': 5,
            'svm_smote_k_neighbors': 5,
            'enn_n_neighbors': 5
        }
        
        if mode == "普通模式":
            # 选择普通模式处理方法
            normal_options = ["multi_class_balance", "skip"]
            normal_menu = interactive(normal_options, title="选择处理方法", description="请选择普通模式处理方法:")
            normal_selected = normal_menu.run()
            normal_selected_list = ensure_list(normal_selected)
            choice1_normal = normal_selected_list[0] if normal_selected_list else "skip"
            sample_params['choice1_normal'] = [choice1_normal]
            
            if choice1_normal == "multi_class_balance":
                # 选择平衡方法
                balance_options = ["oversample", "undersample"]
                balance_menu = interactive(balance_options, title="选择平衡方法", description="请选择平衡方法:")
                balance_selected = balance_menu.run()
                balance_selected_list = ensure_list(balance_selected)
                balance_method = balance_selected_list[0] if balance_selected_list else "oversample"
                sample_params['balance_method'] = balance_method
                
                # 输入随机种子
                random_state = input("请输入随机种子 (默认42): ")
                sample_params['random_state'] = int(random_state) if random_state else 42
        else:
            # 选择高级模式处理方法
            advance_options = ["MY_high_sample", "skip"]
            advance_menu = interactive(advance_options, title="选择处理方法", description="请选择高级模式处理方法:")
            advance_selected = advance_menu.run()
            advance_selected_list = ensure_list(advance_selected)
            choice1_advance = advance_selected_list[0] if advance_selected_list else "skip"
            sample_params['choice1_advance'] = [choice1_advance]
            
            if choice1_advance == "MY_high_sample":
                # 选择高级采样方法
                high_sample_options = [
                    "SMOTE",
                    "ADASYN",
                    "BorderlineSMOTE",
                    "SVMSMOTE",
                    "RandomOverSampler",
                    "RandomUnderSampler",
                    "TomekLinks",
                    "EditedNearestNeighbours",
                    "ClusterCentroids"
                ]
                high_sample_menu = interactive(high_sample_options, title="选择高级采样方法", description="请选择高级采样方法:")
                high_sample_selected = high_sample_menu.run()
                high_sample_selected_list = ensure_list(high_sample_selected)
                high_sample_selection = high_sample_selected_list[0] if high_sample_selected_list else "RandomOverSampler"
                sample_params['high_sample_selection'] = high_sample_selection
                
                # 根据选择的方法添加相应参数
                if high_sample_selection == "SMOTE":
                    smote_k = input("请输入SMOTE邻居数 (默认5): ")
                    sample_params['smote_k_neighbors'] = int(smote_k) if smote_k else 5
                elif high_sample_selection == "ADASYN":
                    adasyn_k = input("请输入ADASYN邻居数 (默认5): ")
                    sample_params['adasyn_n_neighbors'] = int(adasyn_k) if adasyn_k else 5
                elif high_sample_selection == "BorderlineSMOTE":
                    borderline_k = input("请输入BorderlineSMOTE邻居数 (默认5): ")
                    sample_params['borderline_smote_k_neighbors'] = int(borderline_k) if borderline_k else 5
                elif high_sample_selection == "SVMSMOTE":
                    svm_k = input("请输入SVMSMOTE邻居数 (默认5): ")
                    sample_params['svm_smote_k_neighbors'] = int(svm_k) if svm_k else 5
                elif high_sample_selection == "EditedNearestNeighbours":
                    enn_k = input("请输入EditedNearestNeighbours邻居数 (默认5): ")
                    sample_params['enn_n_neighbors'] = int(enn_k) if enn_k else 5
        
        # 构建最终结果
        result = {'sample_preprocessing': sample_params}
        
        # 可视化处理路线
        visualize_route(result)
        
        return result


if __name__ == "__main__":
    """
    测试采样处理功能
    """
    import pandas as pd
    import numpy as np
    
    print("=" * 80)
    print("采样处理模块测试")
    print("=" * 80)
    
    # 创建测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'feature1': np.random.normal(50, 10, 100),
        'feature2': np.random.normal(100, 20, 100),
        'feature3': np.random.normal(200, 30, 100),
        'label': ['A'] * 70 + ['B'] * 20 + ['C'] * 10
    })
    
    print("测试数据:")
    print(data)
    print(f"\n数据形状: {data.shape}")
    print(f"列名: {list(data.columns)}")
    print(f"类别分布:")
    print(data['label'].value_counts())
    
    print("\n" + "=" * 80)
    print("测试标签列检测")
    print("=" * 80)
    
    # 测试标签列检测
    label_cols = get_label_columns(data)
    print(f"检测到的标签列: {label_cols}")
    
    print("\n" + "=" * 80)
    print("测试样本分布分析")
    print("=" * 80)
    
    # 测试样本分布分析
    sample_route = analyze_sample_distribution(data, label_cols)
    if sample_route:
        label_col = list(sample_route.keys())[0]
        analysis = sample_route[label_col]
        print(f"标签列: {label_col}")
        print(f"类别数量: {analysis['num_classes']}")
        print(f"总样本数量: {analysis['total_samples']}")
        print(f"类别不平衡度: {analysis['imbalance_ratio']}")
        print(f"推荐方法: {analysis['best_method']}")
        print(f"推荐参数: {analysis['best_params']}")
    
    print("\n" + "=" * 80)
    print("测试主处理函数")
    print("=" * 80)
    
    # 测试主处理函数
    try:
        result = sample_py(data)
        print("\n处理结果:")
        if result == 'skip':
            print("跳过处理")
        else:
            for key, value in result.items():
                print(f"\n{key}:")
                for param_key, param_value in value.items():
                    print(f"  {param_key}: {param_value}")
    except Exception as e:
        print(f"测试过程中出错: {e}")
    
    print("\n" + "=" * 80)
    print("测试完成!")
    print("=" * 80)
