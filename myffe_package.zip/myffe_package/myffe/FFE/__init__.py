# FFE 特征工程框架
# 包含myffe版本的所有核心功能

from .myffe import (
    FFE_config,
    FFE_console,
    RouteConfig,
    visualize_route,
    describe_data,
    evaluate_dataset,
    print_evaluation_result,
    get_route_params,
    show_available_routes,
    show_routes_visual,
    process_data,
    get_recommended_route
)

__all__ = [
    'FFE_config',
    'FFE_console',
    'RouteConfig',
    'visualize_route',
    'describe_data',
    'evaluate_dataset',
    'print_evaluation_result',
    'get_route_params',
    'show_available_routes',
    'show_routes_visual',
    'process_data',
    'get_recommended_route'
]

# 版本信息
__version__ = '3.3.0'

# 便捷导入别名
FFE = FFE_console
Config = FFE_config

# 添加到__all__
__all__.extend(['FFE', 'Config'])

# 导出主要功能
def process(data, data_label, route=1, save_path='./processed_data.csv', **kwargs):
    """
    处理数据的便捷函数（简化版）
    
    Args:
        data (DataFrame): 输入数据
        data_label (str): 标签列名称
        route (int): 预定义路线编号，默认为1（基础路线）
        save_path (str): 处理后数据的保存路径
        **kwargs: 其他参数
    
    Returns:
        DataFrame: 处理后的数据
    """
    return process_data(data, data_label, route_number=route, save_path=save_path, **kwargs)

def pipeline(data_label, route=1, **kwargs):
    """
    创建特征工程流水线（简化版）
    
    Args:
        data_label (str): 标签列名称
        route (int): 预定义路线编号，默认为1（基础路线）
        **kwargs: 其他参数
    
    Returns:
        tuple: (console, clean_tools) - 控制台实例和预处理工具字典
    """
    from .myffe import FFE
    ffe = FFE()
    return ffe.create_pipeline(data_label, route_number=route, **kwargs)

# 添加到__all__
__all__.extend(['process', 'pipeline'])

# 显示可用路线的便捷函数
def routes():
    """
    显示所有可用的预定义路线
    """
    show_available_routes()

# 添加到__all__
__all__.append('routes')
