﻿"""
参数处理工具模块
用于统一处理各种参数格式，特别是列表和字符串之间的转换
"""
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))

from myffe.tools.color_printer import ColorPrinter


def convert_to_list(param, param_name="参数"):      #这个是主要的接口是用来将参数转换为列表格式的
    """
    将参数转换为列表格式
    
    支持的输入格式：
    - 列表: ['col1', 'col2'] -> ['col1', 'col2']
    - 字符串（逗号分隔）: 'col1, col2' -> ['col1', 'col2']
    - 字符串（单个）: 'col1' -> ['col1']
    - None: []
    
    Args:
        param: 要转换的参数
        param_name: 参数名称（用于错误提示）
        
    Returns:
        list: 转换后的列表
        
    Examples:
        >>> convert_to_list('col1, col2')
        ['col1', 'col2']
        >>> convert_to_list(['col1', 'col2'])
        ['col1', 'col2']
        >>> convert_to_list('col1')
        ['col1']
        >>> convert_to_list(None)
        []
    """
    if param is None:
        return []
    
    if isinstance(param, list):
        # 如果已经是列表，直接返回
        return param
    
    if isinstance(param, str):
        # 如果是字符串，按逗号分隔
        if param.strip() == '':
            return []
        return [col.strip() for col in param.split(',')]
    
    # 如果是其他类型，尝试转换为列表
    try:
        return list(param)
    except Exception as e:
        ColorPrinter.print_error(f"参数 {param_name} 转换失败: {e}")
        return []


def validate_columns(data, columns, param_name="列名"):
    """
    验证列名是否存在于数据框中
    
    Args:
        data: pandas DataFrame
        columns: 列名列表
        param_name: 参数名称（用于错误提示）
        
    Returns:
        tuple: (valid_columns, invalid_columns)
        
    Examples:
        >>> data = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
        >>> valid, invalid = validate_columns(data, ['col1', 'col3'])
        >>> valid
        ['col1']
        >>> invalid
        ['col3']
    """
    import pandas as pd
    
    if not isinstance(data, pd.DataFrame):
        ColorPrinter.print_error(f"数据类型错误，期望 pandas DataFrame，实际: {type(data)}")
        return [], columns
    
    valid_columns = []
    invalid_columns = []
    
    for col in columns:
        if col in data.columns:
            valid_columns.append(col)
        else:
            invalid_columns.append(col)
    
    if invalid_columns:
        ColorPrinter.print_warning(f"{param_name} 中包含不存在的列: {invalid_columns}")
    
    return valid_columns, invalid_columns


def ensure_list(param, default=None):
    """
    确保参数是列表格式，如果不是则使用默认值
    
    Args:
        param: 要检查的参数
        default: 默认值（如果 param 不是列表且不是 None）
        
    Returns:
        list: 列表格式的参数
        
    Examples:
        >>> ensure_list(['col1', 'col2'])
        ['col1', 'col2']
        >>> ensure_list('col1')
        ['col1']
        >>> ensure_list(None, ['default'])
        ['default']
    """
    if param is None:
        return default if default is not None else []
    
    if isinstance(param, list):
        return param
    
    if isinstance(param, str):
        return [param]
    
    return [param] if param is not None else []


def normalize_column_names(columns):                #这个是用来标准化列名的，去除空格和特殊字符
    """
    标准化列名，去除空格和特殊字符
    
    Args:
        columns: 列名列表
        
    Returns:
        list: 标准化后的列名列表
        
    Examples:
        >>> normalize_column_names([' col1 ', ' col2 '])
        ['col1', 'col2']
    """
    if not isinstance(columns, list):
        columns = convert_to_list(columns)
    
    return [col.strip() for col in columns if col.strip()]


def get_valid_columns(data, columns, param_name="列名"):
    """
    获取数据框中存在的有效列名
    
    Args:
        data: pandas DataFrame
        columns: 列名列表或字符串
        param_name: 参数名称（用于错误提示）
        
    Returns:
        list: 有效的列名列表
        
    Examples:
        >>> data = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
        >>> get_valid_columns(data, ['col1', 'col3'])
        ['col1']
    """
    columns = convert_to_list(columns, param_name)
    columns = normalize_column_names(columns)
    valid_columns, _ = validate_columns(data, columns, param_name)
    
    return valid_columns


if __name__ == "__main__":
    import pandas as pd
    
    print("=" * 60)
    print("参数处理工具测试")
    print("=" * 60)
    
    # 测试 convert_to_list
    print("\n测试 convert_to_list:")
    print(f"字符串 'col1, col2': {convert_to_list('col1, col2')}")
    print(f"列表 ['col1', 'col2']: {convert_to_list(['col1', 'col2'])}")
    print(f"字符串 'col1': {convert_to_list('col1')}")
    print(f"None: {convert_to_list(None)}")
    
    # 测试 validate_columns
    print("\n测试 validate_columns:")
    data = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
    valid, invalid = validate_columns(data, ['col1', 'col3'])
    print(f"有效列: {valid}")
    print(f"无效列: {invalid}")
    
    # 测试 ensure_list
    print("\n测试 ensure_list:")
    print(f"列表 ['col1', 'col2']: {ensure_list(['col1', 'col2'])}")
    print(f"字符串 'col1': {ensure_list('col1')}")
    print(f"None: {ensure_list(None, ['default'])}")
    
    # 测试 normalize_column_names
    print("\n测试 normalize_column_names:")
    print(f"[' col1 ', ' col2 ']: {normalize_column_names([' col1 ', ' col2 '])}")
    
    # 测试 get_valid_columns
    print("\n测试 get_valid_columns:")
    valid_cols = get_valid_columns(data, ['col1', 'col3'])
    print(f"有效列: {valid_cols}")
    
    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
