﻿"""
数据集描述模块
用于生成MFM框架的数据集描述报告
"""

def describe_data(data):
    """
    生成数据集的详细描述报告
    
    参数:
        data: pandas DataFrame - 输入数据集
    
    返回:
        dict - 数据集描述信息
    """
    import pandas as pd
    import numpy as np
    
    print("=" * 80)
    print("1. 数据集基本信息")
    print("=" * 80)
    
    # 初始化描述字典
    description = {}
    
    # 1. 基本信息
    print("\n1. 基本信息")
    print("-" * 40)
    print(f"数据形状: {data.shape}")
    print(f"行数: {data.shape[0]}")
    print(f"列数: {data.shape[1]}")
    print(f"\n列名: {data.columns.tolist()}")
    print(f"\n数据类型:")
    dtype_counts = data.dtypes.value_counts()
    print(dtype_counts)
    print(f"\n索引: {data.index}")
    
    description['basic'] = {
        'shape': data.shape,
        'columns': data.columns.tolist(),
        'dtype_counts': dtype_counts.to_dict()
    }
    
    # 2. 数据质量
    print("\n2. 数据质量")
    print("-" * 40)
    missing_values = data.isnull().sum()
    missing_ratio = (data.isnull().sum() / len(data) * 100).round(2)
    missing_info = pd.DataFrame({
        '缺失值数量': missing_values,
        '缺失比例(%)': missing_ratio
    })
    print("缺失值情况:")
    missing_cols = missing_info[missing_info['缺失值数量'] > 0]
    print(missing_cols)
    
    # 检查重复行
    try:
        # 尝试检查重复行
        duplicate_count = data.duplicated().sum()
        print(f"\n重复行数: {duplicate_count}")
    except TypeError:
        # 处理无法比较的情况
        print("\n无法检查重复行，可能包含无法比较的类型")
        duplicate_count = 0
    
    description['quality'] = {
        'missing_values': missing_values.to_dict(),
        'missing_ratio': missing_ratio.to_dict(),
        'duplicate_rows': duplicate_count
    }
    
    # 3. 数据分布
    print("\n3. 数据分布")
    print("-" * 40)
    
    # 数值型
    numeric_cols = data.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 0:
        print(f"数值列 ({len(numeric_cols)}): {numeric_cols.tolist()}")
        print("统计信息:")
        numeric_stats = data[numeric_cols].describe().round(2)
        print(numeric_stats)
        
        # 相关性分析
        if len(numeric_cols) > 1:
            corr_matrix = data[numeric_cols].corr()
            print("\n相关性矩阵:")
            print(corr_matrix.round(2))
            
            description['numeric_correlation'] = corr_matrix.to_dict()
        
        description['numeric_stats'] = numeric_stats.to_dict()
    
    # 分类型
    categorical_cols = data.select_dtypes(include=['object', 'category']).columns
    if len(categorical_cols) > 0:
        print(f"\n分类型列 ({len(categorical_cols)}): {categorical_cols.tolist()}")
        cat_info = {}
        for col in categorical_cols:
            # 处理可能的DataFrame类型列
            col_data = data[col]
            if isinstance(col_data, pd.DataFrame):
                # 如果是DataFrame，取第一列
                col_data = col_data.iloc[:, 0]
            
            unique_count = col_data.nunique()
            if unique_count > 0:
                mode_result = col_data.mode()
                top_value = mode_result.iloc[0] if not mode_result.empty else '?'
            else:
                top_value = '?'
            
            value_counts = col_data.value_counts()
            print(f"  {col}: {unique_count}个唯一值, 最常见值: {top_value}")
            if unique_count <= 10:  # 只显示唯一值较少的列
                print(f"    分布: {dict(value_counts.head(5))}")
            cat_info[col] = {
                'unique_count': unique_count,
                'top_value': top_value,
                'value_counts': value_counts.to_dict()
            }
        description['categorical_info'] = cat_info
    
    # 时间型
    datetime_cols = data.select_dtypes(include=['datetime64']).columns
    if len(datetime_cols) > 0:
        print(f"\n时间型列 ({len(datetime_cols)}): {datetime_cols.tolist()}")
        time_info = {}
        for col in datetime_cols:
            min_val = data[col].min()
            max_val = data[col].max()
            time_range = max_val - min_val
            print(f"  {col}: 从 {min_val} 到 {max_val} (范围: {time_range})")
            time_info[col] = {
                'min': min_val,
                'max': max_val,
                'range': str(time_range)
            }
        description['time_info'] = time_info
    
    # 4. 数据样本
    print("\n4. 数据样本")
    print("-" * 40)
    print("前5行:")
    print(data.head())
    print("\n随机5行:")
    sample_data = data.sample(min(5, len(data)))
    print(sample_data)
    
    # 5. 处理建议
    print("\n5. 处理建议")
    print("-" * 40)
    
    suggestions = []
    
    # 缺失值处理建议
    high_missing_cols = missing_ratio[missing_ratio > 50].index.tolist()
    medium_missing_cols = missing_ratio[(missing_ratio > 10) & (missing_ratio <= 50)].index.tolist()
    low_missing_cols = missing_ratio[(missing_ratio > 0) & (missing_ratio <= 10)].index.tolist()
    
    if high_missing_cols:
        print(f"建议  缺失值>50%的列: {high_missing_cols}")
        print("   可以使用 myffe.preprocessing.nan_preprocessing 中的 drop_col_high_missing 方法")
        suggestions.append(f"高缺失值列: {high_missing_cols}")
    
    if medium_missing_cols:
        print(f"建议  缺失值在10-50%的列: {medium_missing_cols}")
        print("   可以使用 myffe.preprocessing.nan_preprocessing 进行填充处理")
        suggestions.append(f"中等缺失值列: {medium_missing_cols}")
    
    if low_missing_cols:
        print(f"建议  缺失值<10%的列: {low_missing_cols}")
        print("   可以使用 myffe.preprocessing.nan_preprocessing 进行填充处理")
        suggestions.append(f"低缺失值列: {low_missing_cols}")
    
    # 重复行处理建议
    try:
        if data.duplicated().sum() > 0:
            print(f"建议  发现 {data.duplicated().sum()} 个重复行")
            print("   可以使用 pandas 的 drop_duplicates() 方法删除重复行")
            suggestions.append(f"重复行: {data.duplicated().sum()}")
    except TypeError:
        # 处理无法比较的情况
        pass
    
    # 单一值列处理建议
    single_value_cols = []
    for col in data.columns:
        # 处理可能的DataFrame类型列
        col_data = data[col]
        if isinstance(col_data, pd.DataFrame):
            # 如果是DataFrame，取第一列
            col_data = col_data.iloc[:, 0]
        if col_data.nunique() == 1:
            single_value_cols.append(col)
    
    if single_value_cols:
        print(f"建议  单一值列: {single_value_cols}")
        print("   可以使用 myffe.preprocessing.specify_preprocessing 中的 drop_col 方法删除")
        suggestions.append(f"单一值列: {single_value_cols}")
    
    # 高基数类别处理建议
    if len(categorical_cols) > 0:
        high_cardinality_cols = []
        for col in categorical_cols:
            # 处理可能的DataFrame类型列
            col_data = data[col]
            if isinstance(col_data, pd.DataFrame):
                # 如果是DataFrame，取第一列
                col_data = col_data.iloc[:, 0]
            if col_data.nunique() > 100:
                high_cardinality_cols.append(col)
        
        if high_cardinality_cols:
            print(f"建议  高 cardinality 类别列: {high_cardinality_cols}")
            print("   可以使用 myffe.preprocessing.str_preprocessing 进行处理")
            suggestions.append(f"高 cardinality 列: {high_cardinality_cols}")
    
    # 时间列处理建议
    if len(datetime_cols) > 0:
        print(f"建议  时间列: {datetime_cols.tolist()}")
        print("   可以使用 myffe.preprocessing.time_preprocessing 进行时间特征提取")
        suggestions.append(f"时间列: {datetime_cols.tolist()}")
    
    # 数值列处理建议
    if len(numeric_cols) > 0:
        print(f"建议  数值列: {numeric_cols.tolist()}")
        print("   可以使用 myffe.preprocessing.standard_preprocessing 或 normalized_preprocessing 进行标准化/归一化")
        suggestions.append(f"数值列: {numeric_cols.tolist()}")
    
    description['suggestions'] = suggestions
    
    print("=" * 80+"\n")    
    print("数据集描述完成")
    print("=" * 80)
    
    return description
