﻿import pandas as pd
import numpy as np
import sys
import os

# 添加包含MFM模块的目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_dir))))
sys.path.append(parent_dir)
print(f"Added parent directory to sys.path: {parent_dir}")

from MFM.TOOLS_dir.交互式 import interactive
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.param_utils import convert_to_list
from myffe.route.src.predefined_routes import get_route_params, show_available_routes, show_routes_visual
from myffe.route.src.auto_route import auto_routes

class UnifiedConfigManager:
    """统一配置管理器，结合智能推荐、预制路线和交互式配置"""
    
    def __init__(self):
        self.config = {}
        # 定义所有可用的预制路线
        self.predefined_routes = {
            '基础路线': 1,
            '股票数据路线': 2,
            '文本数据路线': 3,
            '时间序列路线': 4,
            '完整路线': 5,
            '轻量级路线': 6,
            '异常检测路线': 7,
            '特征增强路线': 8,
            '分类数据路线': 9,
            '回归数据路线': 10,
            '中文文本路线': 11,
            '不平衡数据路线': 12,
            '高维数据路线': 13,
            '金融数据路线': 14,
            '医疗数据路线': 15,
            '电商数据路线': 16,
            '社交媒体数据路线': 17,
            '传感器数据路线': 18,
            '多模态数据路线': 19,
            '实时数据路线': 20
        }
    
    def get_config(self, data, mode='interactive'):
        """获取配置参数
        
        Args:
            data: pandas DataFrame，输入数据
            mode: str，配置模式，可选值：'interactive'（交互式）、'auto'（智能推荐）、'predefined'（预制路线）
            
        Returns:
            dict: 配置参数
        """
        if mode == 'auto':
            return self._get_auto_config(data)
        elif mode == 'predefined':
            return self._get_predefined_config()
        else:  # interactive
            return self._get_interactive_config(data)
    
    def _get_auto_config(self, data):
        """获取智能推荐配置"""
        ColorPrinter.print_info("=== 智能推荐模式 ===")
        
        # 创建临时文件来存储数据，因为auto_routes类需要从文件读取
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as temp_file:
            data.to_csv(temp_file, index=False)
            temp_file_path = temp_file.name
        
        try:
            # 使用auto_routes类生成推荐路由
            auto_route = auto_routes(ways='pandas', drop_threshold=0.5)
            route = auto_route(temp_file_path)
        finally:
            # 清理临时文件
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
        
        return route
    
    def _get_predefined_config(self):
        """获取预制路线配置"""
        ColorPrinter.print_info("=== 预制路线模式 ===")
        
        # 显示可用的预制路线
        route_names = list(self.predefined_routes.keys())
        if not route_names:
            ColorPrinter.print_warning("没有可用的预制路线")
            return {}
        
        # 让用户选择预制路线
        selected_route = interactive(route_names, title="请选择预制路线").run()
        ColorPrinter.print_success(f"已选择预制路线：{selected_route}")
        
        # 获取路线编号
        route_number = self.predefined_routes[selected_route]
        # 使用get_route_params函数获取配置
        config = get_route_params(route_number)
        
        return config
    
    def _get_interactive_config(self, data):
        """获取交互式配置"""
        ColorPrinter.print_info("=== 交互式配置模式 ===")
        
        # 首先让用户选择配置方式
        config_mode = interactive(
            ['智能推荐 + 交互式调整', '预制路线 + 交互式调整', '完全手动配置'],
            title="请选择配置方式"
        ).run()
        
        if config_mode == '智能推荐 + 交互式调整':
            # 先获取智能推荐配置
            auto_config = self._get_auto_config(data)
            # 然后交互式调整
            return self._interactive_adjust(data, auto_config)
        elif config_mode == '预制路线 + 交互式调整':
            # 先获取预制路线配置
            predefined_config = self._get_predefined_config()
            # 然后交互式调整
            return self._interactive_adjust(data, predefined_config)
        else:  # 完全手动配置
            return self._manual_config(data)
    
    def _interactive_adjust(self, data, base_config):
        """交互式调整配置"""
        ColorPrinter.print_info("=== 交互式调整配置 ===")
        ColorPrinter.print_info(f"当前配置：{base_config}")
        
        # 让用户选择是否调整配置
        adjust = interactive(['是', '否'], title="是否调整配置？").run()
        if adjust == '否':
            return base_config
        
        # 让用户选择要调整的预处理步骤
        if base_config:
            available_steps = list(base_config.keys())
            if available_steps:
                selected_steps = interactive(available_steps, title="请选择要调整的预处理步骤").run()
                ColorPrinter.print_success(f"已选择调整步骤：{selected_steps}")
                
                # 这里可以添加具体的步骤调整逻辑
                # 例如，根据选择的步骤类型，提供相应的参数调整选项
                
        ColorPrinter.print_success("配置调整完成")
        return base_config
    
    def _manual_config(self, data):
        """完全手动配置"""
        ColorPrinter.print_info("=== 完全手动配置 ===")
        
        # 让用户选择需要的预处理步骤
        available_tools = [
            'nan_preprocessing', 'outlier_preprocessing', 'str_preprocessing',
            'time_preprocessing', 'relative_preprocessing', 'specify_preprocessing',
            'standard_preprocessing', 'normalized_preprocessing', 'sample_preprocessing'
        ]
        
        selected_tools = interactive(available_tools, title="请选择需要的预处理步骤").run()
        ColorPrinter.print_success(f"已选择预处理步骤：{selected_tools}")
        
        # 为每个选择的步骤配置参数
        manual_config = {}
        for tool in selected_tools:
            ColorPrinter.print_info(f"正在配置 {tool}...")
            # 这里可以添加具体的参数配置逻辑
            # 例如，根据工具类型，提供相应的参数配置选项
            manual_config[tool] = {}
        
        ColorPrinter.print_success("手动配置完成")
        return manual_config

if __name__ == "__main__":
    # 测试代码
    import pandas as pd
    import numpy as np
    
    # 创建测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'numeric_col1': np.random.normal(100, 10, 20),
        'numeric_col2': np.random.normal(50, 5, 20),
        'categorical_col': np.random.choice(['A', 'B', 'C'], 20),
        'datetime_col': pd.date_range('2020-01-01', periods=20)
    })
    
    # 随机添加缺失值
    for col in data.columns:
        if col != 'datetime_col':
            mask = np.random.choice([True, False], size=20, p=[0.2, 0.8])
            data.loc[mask, col] = np.nan
    
    # 测试统一配置管理器
    manager = UnifiedConfigManager()
    
    # 测试交互式模式
    ColorPrinter.print_info("\n测试交互式模式：")
    interactive_config = manager.get_config(data, mode='interactive')
    ColorPrinter.print_success("交互式配置结果：")
    print(interactive_config)
    
    # 测试智能推荐模式
    ColorPrinter.print_info("\n测试智能推荐模式：")
    auto_config = manager.get_config(data, mode='auto')
    ColorPrinter.print_success("智能推荐配置结果：")
    print(auto_config)
    
    # 测试预制路线模式
    ColorPrinter.print_info("\n测试预制路线模式：")
    predefined_config = manager.get_config(data, mode='predefined')
    ColorPrinter.print_success("预制路线配置结果：")
    print(predefined_config)
