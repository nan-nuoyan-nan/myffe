# 标准化方法详解

## 1. 标准化的概念与重要性

标准化是数据预处理中的关键步骤，它将不同范围的特征值转换为统一的尺度，有助于：

- 提高模型训练效率和收敛速度
- 避免特征值范围差异导致的模型偏见
- 增强模型的稳定性和泛化能力
- 使不同特征之间具有可比性
- 满足某些算法对输入数据分布的要求

## 2. 常用标准化方法

### 2.1 Z-score 标准化 (Z-score Standardization)

#### 原理与公式
- **公式**：对于特征 x ，标准化后的值为：
  
  x' = (x - μ) / σ
  
  其中，μ 是特征的均值，σ 是特征的标准差

- **结果**：数据被转换为均值为 0，标准差为 1 的分布

#### 使用场景
- 适用于正态分布的数据
- 当特征的均值和标准差有明确的物理意义时
- 大多数机器学习算法的默认选择
- 适用于需要保持数据相对关系的场景

#### 示例数据

| 原始数据 | Z-score 标准化结果 |
|---------|-------------------|
| 10 | -1.4142 |
| 20 | -0.7071 |
| 30 | 0.0000 |
| 40 | 0.7071 |
| 50 | 1.4142 |

#### 特点分析
- 保留了数据的分布形状
- 对异常值敏感
- 计算简单，易于理解
- 结果范围不固定，可能为负值

### 2.2 Min-Max 标准化 (Min-Max Standardization)

#### 原理与公式
- **公式**：对于特征 x ，标准化后的值为：
  
  x' = (x - min(x)) / (max(x) - min(x))
  
  其中，min(x) 是特征的最小值，max(x) 是特征的最大值

- **结果**：数据被缩放到 [0, 1] 区间

#### 使用场景
- 当需要将数据缩放到固定范围时
- 适用于有明显边界的数据
- 神经网络输入层的常用选择
- 适用于对特征值范围有明确要求的算法

#### 示例数据

| 原始数据 | Min-Max 标准化结果 |
|---------|-------------------|
| 10 | 0.0000 |
| 20 | 0.2500 |
| 30 | 0.5000 |
| 40 | 0.7500 |
| 50 | 1.0000 |

#### 特点分析
- 结果范围固定在 [0, 1]
- 对异常值敏感，因为会影响 min 和 max 的值
- 计算简单，易于理解
- 保留了数据的相对关系

### 2.3 MaxAbs 标准化 (MaxAbs Standardization)

#### 原理与公式
- **公式**：对于特征 x ，标准化后的值为：
  
  x' = x / max(|x|)
  
  其中，max(|x|) 是特征绝对值的最大值

- **结果**：数据被缩放到 [-1, 1] 区间

#### 使用场景
- 适用于包含负值的数据
- 对稀疏数据友好，因为不会改变数据的稀疏性
- 当数据中包含零值且需要保持零时
- 适用于对比例敏感的算法

#### 示例数据

| 原始数据 | MaxAbs 标准化结果 |
|---------|-------------------|
| -20 | -0.4000 |
| -10 | -0.2000 |
| 0 | 0.0000 |
| 10 | 0.2000 |
| 50 | 1.0000 |

#### 特点分析
- 结果范围固定在 [-1, 1]
- 对异常值敏感
- 保持数据的稀疏性
- 计算简单，效率高

### 2.4 RobustScaler 标准化 (RobustScaler Standardization)

#### 原理与公式
- **公式**：对于特征 x ，标准化后的值为：
  
  x' = (x - Q2(x)) / (Q3(x) - Q1(x))
  
  其中，Q2(x) 是特征的中位数，Q3(x) - Q1(x) 是四分位距 (IQR)

- **结果**：数据被中心化并缩放到基于四分位数的尺度

#### 使用场景
- **对异常值非常鲁棒**，适合含有异常值的数据集
- 当数据分布不对称时
- 适用于需要稳健标准化的场景
- 当数据中存在极端值时

#### 示例数据

| 原始数据 | RobustScaler 标准化结果 |
|---------|------------------------|
| 10 | -1.0000 |
| 20 | -0.5000 |
| 30 | 0.0000 |
| 40 | 0.5000 |
| 100 | 3.5000 |

#### 特点分析
- 对异常值具有很强的鲁棒性
- 结果范围不固定
- 计算稍复杂，但结果稳定
- 不依赖于数据的整体分布

### 2.5 QuantileTransformer 标准化 (QuantileTransformer Standardization)

#### 原理与公式
- **步骤**：
  1. 将数据映射到均匀分布
  2. 可选：将均匀分布转换为其他分布（如正态分布）

- **结果**：数据被映射到指定的分布（默认为均匀分布）

#### 使用场景
- 适用于非正态分布的数据
- 当需要将数据转换为特定分布时
- 对异常值具有一定的鲁棒性
- 适用于需要数据均匀分布的算法

#### 示例数据

| 原始数据 | QuantileTransformer 标准化结果 |
|---------|-------------------------------|
| 10 | 0.0000 |
| 20 | 0.2500 |
| 30 | 0.5000 |
| 40 | 0.7500 |
| 100 | 1.0000 |

#### 特点分析
- 可以将数据映射到指定分布
- 对异常值有一定的鲁棒性
- 计算复杂度较高
- 适用于各种数据分布

### 2.6 均值归一化 (Mean Normalization)

#### 原理与公式
- **公式**：对于特征 x ，归一化后的值为：
  
  x' = x - μ
  
  其中，μ 是特征的均值

- **结果**：数据被中心化，均值为 0

#### 使用场景
- 当只需要中心化数据时
- 适用于对数据均值敏感的算法
- 当不需要缩放数据范围时
- 适用于保持数据原始尺度的场景

#### 示例数据

| 原始数据 | 均值归一化结果 |
|---------|----------------|
| 10 | -20.0 |
| 20 | -10.0 |
| 30 | 0.0 |
| 40 | 10.0 |
| 50 | 20.0 |

#### 特点分析
- 数据均值为 0
- 不改变数据的方差和范围
- 计算简单，效率高
- 保留了数据的原始尺度

### 2.7 单位长度归一化 (Unit Length Normalization)

#### 原理与公式
- **公式**：对于特征 x ，归一化后的值为：
  
  x' = x / ||x||
  
  其中，||x|| 是特征向量的范数（默认为 L2 范数）

- **结果**：特征向量的长度为 1

#### 使用场景
- 当特征向量的方向比大小更重要时
- 适用于距离-based 算法（如 KNN、SVM）
- 当需要保持特征向量方向时
- 适用于文本分类等需要向量相似度计算的场景

#### 示例数据

| 原始数据 | 单位长度归一化结果 |
|---------|-------------------|
| 1 | 0.2673 |
| 2 | 0.5345 |
| 3 | 0.8018 |

#### 特点分析
- 特征向量长度为 1
- 保持特征向量的方向不变
- 对异常值敏感
- 计算简单，效率高

### 2.8 自定义缩放 (Custom Scaling)

#### 原理与公式
- **公式**：根据数据特性自定义缩放，例如：
  
  x' = (x - μ) / (2σ)
  
  其中，μ 是特征的均值，σ 是特征的标准差

- **结果**：数据被缩放到 [-0.5, 0.5] 范围

#### 使用场景
- 当需要自定义缩放范围时
- 适用于对数据范围有特殊要求的算法
- 当需要平衡不同特征的重要性时
- 适用于需要精细控制缩放程度的场景

#### 示例数据

| 原始数据 | 自定义缩放结果 |
|---------|----------------|
| 10 | -0.5000 |
| 20 | -0.2500 |
| 30 | 0.0000 |
| 40 | 0.2500 |
| 50 | 0.5000 |

#### 特点分析
- 结果范围可自定义
- 计算灵活，可根据需要调整
- 适用于特殊场景
- 保留了数据的相对关系

## 3. 标准化方法选择指南

### 3.1 根据数据特性选择

| 数据特性 | 推荐标准化方法 |
|---------|----------------|
| 正态分布 | Z-score 标准化 |
| 有明显边界 | Min-Max 标准化 |
| 包含负值 | MaxAbs 标准化 |
| 含有异常值 | RobustScaler 标准化 |
| 非正态分布 | QuantileTransformer 标准化 |
| 需要保持零值 | MaxAbs 标准化 |
| 稀疏数据 | MaxAbs 标准化 |

### 3.2 根据算法需求选择

| 算法类型 | 推荐标准化方法 |
|---------|----------------|
| 线性模型 (线性回归、逻辑回归) | Z-score 标准化 |
| 神经网络 | Min-Max 标准化 (0-1范围) |
| 距离-based 算法 (KNN、SVM) | Z-score 或单位长度归一化 |
| 树模型 (决策树、随机森林) | 通常不需要标准化 |
| PCA | Z-score 标准化 |
| 聚类算法 | Z-score 标准化 |

### 3.3 根据计算效率选择

| 标准化方法 | 计算复杂度 | 适用场景 |
|-----------|------------|----------|
| Z-score、Min-Max、MaxAbs | 低 | 大规模数据 |
| RobustScaler | 中 | 中等规模数据 |
| QuantileTransformer | 高 | 小规模数据 |
| 均值归一化、单位长度归一化 | 低 | 大规模数据 |
| 自定义缩放 | 低到中 | 根据具体实现 |

## 4. 代码实现示例

### 4.1 使用 scikit-learn 实现

```python
from sklearn.preprocessing import StandardScaler, MinMaxScaler, MaxAbsScaler, RobustScaler, QuantileTransformer
import numpy as np
import pandas as pd

# 示例数据
data = pd.DataFrame({
    'feature1': [10, 20, 30, 40, 50],
    'feature2': [-20, -10, 0, 10, 50],
    'feature3': [10, 20, 30, 40, 100]  # 包含异常值
})

# Z-score 标准化
zscore_scaler = StandardScaler()
zscore_normalized = zscore_scaler.fit_transform(data)

# Min-Max 标准化
minmax_scaler = MinMaxScaler()
minmax_normalized = minmax_scaler.fit_transform(data)

# MaxAbs 标准化
maxabs_scaler = MaxAbsScaler()
maxabs_normalized = maxabs_scaler.fit_transform(data)

# RobustScaler 标准化
robust_scaler = RobustScaler()
robust_normalized = robust_scaler.fit_transform(data)

# QuantileTransformer 标准化
quantile_scaler = QuantileTransformer(output_distribution='uniform')
quantile_normalized = quantile_scaler.fit_transform(data)

# 均值归一化
def mean_normalize(data):
    data = data.copy()
    for col in data.columns:
        mean_val = data[col].mean()
        data[col] = data[col] - mean_val
    return data

mean_normalized = mean_normalize(data)

# 单位长度归一化
def unit_length_normalize(data):
    data = data.copy()
    for col in data.columns:
        norm = np.linalg.norm(data[col])
        if norm > 0:
            data[col] = data[col] / norm
    return data

unit_length_normalized = unit_length_normalize(data)

# 自定义缩放
def custom_scale(data):
    data = data.copy()
    for col in data.columns:
        mean_val = data[col].mean()
        std_val = data[col].std()
        if std_val > 0:
            data[col] = (data[col] - mean_val) / (2 * std_val)
    return data

custom_normalized = custom_scale(data)
```

### 4.2 使用 myffe 库实现

```python
from myffe.preprocessing.standard_preprocessing import StandardScaler
import pandas as pd
import numpy as np

# 示例数据
data = pd.DataFrame({
    'feature1': np.random.normal(50, 10, 20),
    'feature2': np.random.normal(100, 20, 20),
    'feature3': np.random.normal(200, 30, 20)
})

# 添加一些异常值
data.loc[0, 'feature1'] = 150
data.loc[1, 'feature2'] = 300
data.loc[2, 'feature3'] = 500

# 对不同列应用不同的标准化方法
stand_params = {
    'scaler_method_choice': ['Z-score标准化', 'Min-Max标准化', 'RobustScaler标准化'],
    'standard_col': ['feature1', 'feature2', 'feature3']
}

scaler = StandardScaler(shortcut_stand=stand_params)
scaled_data = scaler(data)
```

## 5. 总结

标准化是数据预处理中的重要步骤，选择合适的标准化方法可以显著提高模型的性能。不同的标准化方法适用于不同的数据特性和算法需求，需要根据具体情况进行选择。

在实际应用中，可以尝试多种标准化方法，并通过交叉验证选择效果最好的一种。同时，对于不同的特征，可以根据其特性选择不同的标准化方法，以达到最佳的预处理效果。

## 6. 常见问题与解决方案

### 6.1 如何处理包含异常值的数据？
- **解决方案**：使用 RobustScaler 标准化，它基于中位数和四分位数，对异常值不敏感。

### 6.2 如何处理稀疏数据？
- **解决方案**：使用 MaxAbs 标准化，它不会改变数据的稀疏性，同时保持零值不变。

### 6.3 如何处理非正态分布的数据？
- **解决方案**：使用 QuantileTransformer 标准化，它可以将数据映射到均匀分布或正态分布。

### 6.4 如何选择合适的标准化方法？
- **解决方案**：
  1. 了解数据的分布特性
  2. 了解算法对输入数据的要求
  3. 尝试多种方法，通过交叉验证选择效果最好的一种
  4. 考虑计算效率和数据规模

### 6.5 标准化后的数据范围应该是多少？
- **答案**：这取决于具体的标准化方法和应用场景：
  - Z-score 标准化：均值为 0，标准差为 1
  - Min-Max 标准化：[0, 1]
  - MaxAbs 标准化：[-1, 1]
  - RobustScaler 标准化：不固定，取决于数据
  - QuantileTransformer 标准化：[0, 1]（均匀分布）
  - 均值归一化：均值为 0，范围不固定
  - 单位长度归一化：向量长度为 1
  - 自定义缩放：根据需要自定义

通过合理选择和应用标准化方法，可以显著提高机器学习模型的性能和稳定性，为后续的模型训练和预测打下良好的基础。