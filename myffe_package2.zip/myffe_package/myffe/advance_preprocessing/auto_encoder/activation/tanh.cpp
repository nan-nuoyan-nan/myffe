//
// Created by HP on 2026/3/17.
//



//这个文件用来编写tanh函数的实现

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <iostream>
#include <cmath>
using namespace std;


void tanh(py::array_t<float>& x) {
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    float* x_ptr = x.mutable_data();//there is a pointer to the input array
    for (int j = 0; j < x_cols; j++) {
        for (int i = 0; i < x_rows; i++) {
            x_ptr[i * x_cols + j] = tanh(x_ptr[i * x_cols + j]);
        }
    }
}
