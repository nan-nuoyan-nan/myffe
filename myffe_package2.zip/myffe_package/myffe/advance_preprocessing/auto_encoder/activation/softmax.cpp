

//这个文件用来写softmax函数的实现

#include <iostream>
#include <cmath>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
using namespace std;
void softmax(py::array_t<float>& x) {
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    float* x_ptr = x.mutable_data();//there is a pointer to the input array
	for (int i = 0; i < x_rows; ++i){
        int max_idx = 0;
 	    for (int j = 0; j <x_cols; ++j){
			// 多维度的行之间是独立的计算
			// 先找到当前行的最大值，计算所有的数字与它的差值保证数值稳定性
			if (x_ptr[i * x_cols + max_idx] < x_ptr[i * x_cols + j] ) {
                max_idx = j;
            }
		}
		x_ptr[i * x_cols + max_idx] = x_ptr[i * x_cols + max_idx];
		float row_sum = 0.0f;
		for (int j = 0; j < x_cols; ++j) {
			float temp = exp(x_ptr[i * x_cols + j] - x_ptr[i * x_cols + max_idx]);
			row_sum += temp;
		}
		for (int j = 0; j < x_cols; ++j) {
			x_ptr[i * x_cols + j] = temp / row_sum;
		}
	}
}



















