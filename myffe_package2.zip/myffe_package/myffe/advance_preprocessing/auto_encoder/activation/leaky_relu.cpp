//
// Created by HP on 2026/3/16.
//


//这个文件用来编写leaky_relu函数的实现

#include <cmath>
#include <iostream>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
using namespace std;

// 这里使用alpha=0.01
void leaky_relu(py::array<float>& x) {
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    // 这里是获取指向输入数组的指针
    float* x_ptr = x.mutable_data();// there is a pointer to the input array
        for (int j = 0; j< x_cols; ++j) {
             x_ptr[i * x_cols + j] = max(0.01f * x_ptr[i * x_cols + j], x_ptr[i * x_cols + j]);
        }
    }
}



























