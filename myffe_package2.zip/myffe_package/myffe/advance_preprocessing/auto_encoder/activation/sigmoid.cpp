//
// Created by HP on 2026/3/16.
//

//这个文件用来写sigmoid函数的实现
#include <cmath>
#include <iostream>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
using namespace std;


void sigmoid(py::array_t<float>& x) {
//这里将使用指针高效实现sigmoid函数
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    //这里是获取指向输入数组的指针
    float* x_ptr = x.mutable_data();//there is a pointer to the input array
    for (int i = 0; i < x_rows; ++i) {
        for (int j = 0; j< x_cols; ++j) {
             x_ptr[i * x_cols + j] = 1 / (1 + exp(-x_ptr[i * x_cols + j]));
        }
    }











}



