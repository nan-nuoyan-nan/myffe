//
// Created by HP on 2026/3/17.
//



#include <iostream>
#include <cmath>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
using namespace std;
//下面是gelu函数的实现,这个激活函数是一个平滑的版本的relu函数,它的输出范围是[0,1]

void gelu(py::array_t<float>& x) {
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    const float M_PI = 3.141593f; //这里是圆周率
    const float sqrt_2_over_pi = sqrt(2.0f / M_PI);//这里得到的是2/sqrt(pi)
    float* x_ptr = x.mutable_data();//there is a pointer to the input array
    for (int j = 0; j < x_cols; j++) {
        for (int i = 0; i < x_rows; i++) {
            float cubic = 0.044715f * x_ptr[i * x_cols + j] * x_ptr[i * x_cols + j] * x_ptr[i * x_cols + j];//这里得到的是x的三次方
            float inner = sqrt_2_over_pi * (x_ptr[i * x_cols + j] + cubic);
             x_ptr[i * x_cols + j] = 0.5f * x_ptr[i * x_cols + j] * (1.0f + tanh(inner));
        }
    }
}






