//
// Created by HP on 2026/3/16.
//
//这个文件用来写relu函数的实现
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

//使用0.0f是为了防止编译器报错
//因为编译器默认是double这里会将它转换为float，浪费了时间
//以及他会有精度的报告
void relu(py::array<float>& x) {
    int x_rows = x.shape(0);
    int x_cols = x.shape(1);
    cout<<"x_rows: "<<x_rows<<endl;
    cout<<"x_cols: "<<x_cols<<endl;
    float* x_ptr = x.mutable_data();//there is a pointer to the input array
    for (int i = 0; i < x_rows; ++i) {
        for (int j = 0; j< x_cols; ++j) {
             x_ptr[i * x_cols + j] = max(0.0f, x_ptr[i * x_cols + j]);
        }
    }
}

