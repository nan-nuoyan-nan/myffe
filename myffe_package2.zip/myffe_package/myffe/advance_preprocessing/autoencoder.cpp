//
// Created by HP on 2026/3/16.
//
//这个文件用来写神经网络的自编码器

#include <iostream>
#include <vector>
using namespace std;



int __main__{





}






