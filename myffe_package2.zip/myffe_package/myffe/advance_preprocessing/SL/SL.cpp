//
// Created by HP on 2026/3/16.
//

//这个文件写多层感知机


#include <iostream>
#include <vector>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
using namespace std;



//输入的列是特征的数量，输入的行是样本的数量
//输入的权重矩阵的列是特征的数量，输入的权重矩阵的行是输出的数量
void Single_Layer(
    py::array_t<float> &input,
    py::array_t<float> &weight,
    py::array_t<float> &bias,
    py::array_t<float> &output   //这个是输出的数组
) {

    float* input_ptr = input.mutable_data();//there is a pointer to the input array
    float* weight_ptr = weight.mutable_data();//there is a pointer to the weight array
    float* bias_ptr = bias.mutable_data();//there is a pointer to the bias array
    float* output_ptr = output.mutable_data();//there is a pointer to the output array
    int input_rows = input.shape(0);//there is the number of rows in the input array
    int input_cols = input.shape(1);//there is the number of columns in the input array
    int weight_rows = weight.shape(0);//there is the number of rows in the weight array
    int weight_cols = weight.shape(1);//there is the number of columns in the weight array
    int bias_rows = bias.shape(0);//there is the number of rows in the bias array
    int output_rows = output.shape(0);//there is the number of rows in the output array
    int output_cols = output.shape(1);//there is the number of columns in the output array
    
    // 维度检查
    if (weight_cols != input_cols) {
        throw std::runtime_error("Weight columns must match input columns");
    }
    if (bias_rows != weight_rows) {
        throw std::runtime_error("Bias rows must match weight rows");
    }
    if (output_rows != input_rows || output_cols != weight_rows) {
        throw std::runtime_error("Output shape must be (input_rows, weight_rows)");
    }
    
    cout<<"the bias rows is "<<bias_rows<<endl; 
    cout<<"the weight columns is "<<weight_cols<<endl;
    cout<<"the weight rows is "<<weight_rows<<endl;
    cout<<"the input rows is "<<input_rows<<endl;
    cout<<"the input columns is "<<input_cols<<endl;
    cout<<"the output rows is "<<output_rows<<endl;
    cout<<"the output columns is "<<output_cols<<endl;
    
    //下面进行矩阵计算
    for (int i = 0; i < input_rows; ++i) {
        for (int j = 0; j < weight_rows; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < input_cols; ++k) {
                sum += input_ptr[i * input_cols + k] * weight_ptr[j * weight_cols + k];
            }
            output_ptr[i * output_cols + j] = sum + bias_ptr[j];
        }
    }
}

// Pybind11 绑定
PYBIND11_MODULE(SL, m) {
    m.def("Single_Layer", &Single_Layer, "Perform single layer neural network calculation");
}





























