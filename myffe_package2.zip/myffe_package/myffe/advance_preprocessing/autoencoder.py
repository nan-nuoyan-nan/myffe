"""
this moudle will implement the autoencoder for missing value imputation
这里将使用多层神经网络实现自动编码器，用于缺失值 imputation。
"""



class autoencoder:
    def __init__(self,shortcut_autoencoder):
        self.shortcut_autoencoder = shortcut_autoencoder

    def __call__(self, data):
        if self.shortcut_autoencoder == 'skip':
            return data
        print("welcome the autoencoder")
        self.data = data.copy()





        



        































